<?php

namespace Container7YwCnS4;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder1045a = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerd117b = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties5e360 = [
        
    ];

    public function getConnection()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getConnection', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getMetadataFactory', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getExpressionBuilder', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'beginTransaction', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getCache', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getCache();
    }

    public function transactional($func)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'transactional', array('func' => $func), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'wrapInTransaction', array('func' => $func), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'commit', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->commit();
    }

    public function rollback()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'rollback', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getClassMetadata', array('className' => $className), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'createQuery', array('dql' => $dql), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'createNamedQuery', array('name' => $name), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'createQueryBuilder', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'flush', array('entity' => $entity), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'clear', array('entityName' => $entityName), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->clear($entityName);
    }

    public function close()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'close', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->close();
    }

    public function persist($entity)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'persist', array('entity' => $entity), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'remove', array('entity' => $entity), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'refresh', array('entity' => $entity), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'detach', array('entity' => $entity), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'merge', array('entity' => $entity), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getRepository', array('entityName' => $entityName), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'contains', array('entity' => $entity), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getEventManager', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getConfiguration', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'isOpen', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getUnitOfWork', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getProxyFactory', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'initializeObject', array('obj' => $obj), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'getFilters', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'isFiltersStateClean', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'hasFilters', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return $this->valueHolder1045a->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerd117b = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder1045a) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder1045a = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder1045a->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, '__get', ['name' => $name], $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        if (isset(self::$publicProperties5e360[$name])) {
            return $this->valueHolder1045a->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1045a;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder1045a;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1045a;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder1045a;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, '__isset', array('name' => $name), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1045a;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder1045a;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, '__unset', array('name' => $name), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1045a;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder1045a;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, '__clone', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        $this->valueHolder1045a = clone $this->valueHolder1045a;
    }

    public function __sleep()
    {
        $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, '__sleep', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;

        return array('valueHolder1045a');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerd117b = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerd117b;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerd117b && ($this->initializerd117b->__invoke($valueHolder1045a, $this, 'initializeProxy', array(), $this->initializerd117b) || 1) && $this->valueHolder1045a = $valueHolder1045a;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder1045a;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder1045a;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
