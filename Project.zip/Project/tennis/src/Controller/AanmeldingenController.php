<?php

namespace App\Controller;

use App\Entity\Aanmeldingen;
use App\Form\AanmeldingenType;
use App\Repository\AanmeldingenRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/aanmeldingen')]
class AanmeldingenController extends AbstractController
{
    #[Route('/', name: 'app_aanmeldingen_index', methods: ['GET'])]
    public function index(AanmeldingenRepository $aanmeldingenRepository): Response
    {
        return $this->render('aanmeldingen/index.html.twig', [
            'aanmeldingens' => $aanmeldingenRepository->findAll(),
        ]);
    }

    #[Route('/new', name: 'app_aanmeldingen_new', methods: ['GET', 'POST'])]
    public function new(Request $request, AanmeldingenRepository $aanmeldingenRepository): Response
    {
        $aanmeldingen = new Aanmeldingen();
        $form = $this->createForm(AanmeldingenType::class, $aanmeldingen);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $aanmeldingenRepository->add($aanmeldingen);
            return $this->redirectToRoute('app_aanmeldingen_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('aanmeldingen/new.html.twig', [
            'aanmeldingen' => $aanmeldingen,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_aanmeldingen_show', methods: ['GET'])]
    public function show(Aanmeldingen $aanmeldingen): Response
    {
        return $this->render('aanmeldingen/show.html.twig', [
            'aanmeldingen' => $aanmeldingen,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_aanmeldingen_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Aanmeldingen $aanmeldingen, AanmeldingenRepository $aanmeldingenRepository): Response
    {
        $form = $this->createForm(AanmeldingenType::class, $aanmeldingen);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $aanmeldingenRepository->add($aanmeldingen);
            return $this->redirectToRoute('app_aanmeldingen_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('aanmeldingen/edit.html.twig', [
            'aanmeldingen' => $aanmeldingen,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_aanmeldingen_delete', methods: ['POST'])]
    public function delete(Request $request, Aanmeldingen $aanmeldingen, AanmeldingenRepository $aanmeldingenRepository): Response
    {
        if ($this->isCsrfTokenValid('delete'.$aanmeldingen->getId(), $request->request->get('_token'))) {
            $aanmeldingenRepository->remove($aanmeldingen);
        }

        return $this->redirectToRoute('app_aanmeldingen_index', [], Response::HTTP_SEE_OTHER);
    }
}
